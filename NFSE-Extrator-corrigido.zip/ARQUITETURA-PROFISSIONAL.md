# Arquitetura profissional do Extrator de NFS-e

## Decisão

O produto principal deve ser um aplicativo Windows construído com Tauri. A
versão web deve ser gerada pela mesma base React/TypeScript como alternativa de
compatibilidade e testes. Não devem existir dois parsers ou duas regras fiscais.

## Por que esta arquitetura

- mantém o código atual, que já está funcional e modular;
- evita o peso do Electron;
- abre em uma janela própria no Windows;
- permite gerar instalador MSI/NSIS;
- mantém interface, parser, OCR, validações e Excel compartilhados;
- alterações futuras são feitas uma única vez;
- o build web continua disponível para homologação.

## Comandos

Instalar dependências:

```bash
npm install
```

Desenvolvimento da interface:

```bash
npm run dev
```

Gerar a versão web:

```bash
npm run build:web
```

Abrir a versão desktop durante o desenvolvimento:

```bash
npm run desktop:dev
```

Gerar o aplicativo Windows:

```bash
npm run desktop:build
```

Para compilar o desktop, o computador de desenvolvimento precisa ter Rust,
Microsoft C++ Build Tools e WebView2. O resultado será criado em
`src-tauri/target/release/bundle/`.

## Organização recomendada para evoluções

- `src/lib/nfse`: regras fiscais e extração, sem código visual;
- `src/hooks`: processamento em lote e estado;
- `src/App.tsx`: interface;
- `src-tauri`: empacotamento desktop;
- `dist`: saída web compilada.

Novas regras de notas devem ser implementadas em `src/lib/nfse`, nunca dentro
dos componentes visuais.

## Segurança corporativa

O código não envia PDFs ou dados fiscais para servidores. Para reduzir alertas
do SentinelOne em ambiente corporativo, o instalador final deve ser assinado
com certificado de code signing ou homologado pela equipe de TI. Nenhum
empacotador consegue substituir uma assinatura confiável.
