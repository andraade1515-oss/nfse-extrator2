# Extrator NFS-e

Projeto separado do sistema original. Não usa Supabase, login, dashboard ou banco de dados.

## Instalador para Windows sem acesso de administrador

Consulte [GERAR-EXE-SEM-ADMIN.md](GERAR-EXE-SEM-ADMIN.md). O GitHub gera o instalador em nuvem, e o usuário final recebe somente um `.exe` leve. Não é necessário instalar Visual Studio, Rust, Node.js ou VS Code no computador local.

## Como abrir no VS Code

1. Instale Node.js 20 ou superior.
2. Abra esta pasta no VS Code.
3. Abra o terminal e rode:

```bash
npm install
npm run dev
```

4. Abra no navegador o endereço exibido pelo Vite (normalmente `http://localhost:5173`).

## Como o valor é extraído

O extrator não procura o maior valor do PDF e não escolhe qualquer número perto de um rótulo.

Para preencher **Valor operação/serviço**, ele procura exclusivamente:

- seção `VALOR TOTAL DA NFS-E`;
- campo `VALOR DA OPERAÇÃO / SERVIÇO`.

Assim ele evita confundir o valor da nota com:

- ISSQN;
- IRRF;
- PIS/COFINS;
- IBS/CBS;
- tributos aproximados;
- descontos;
- retenções;
- valor líquido;
- valores existentes na descrição do serviço.

## Campos extraídos

- Número da NFS-e
- Competência
- Data de emissão
- Emitente
- CNPJ/CPF do emitente
- Tomador
- CNPJ/CPF do tomador
- Valor da operação/serviço
- Cancelamento
- Origem da leitura (texto/OCR)
- Campos não identificados

## Segurança da extração

CNPJ e CPF são validados por dígito verificador. Valores monetários, datas e competência também passam por validação. Se o parser não encontrar um campo com segurança, retorna `NÃO IDENTIFICADO` em vez de preencher por aproximação.

## Cancelamentos

O cancelamento é verificado por texto, metadados, objetos gráficos e pela tarja vermelha diagonal. A detecção visual da tarja não depende do OCR e permanece estável em lotes grandes. Quando OCR ainda é necessário, as leituras são colocadas em fila para impedir que uma nota interfira na outra.


## Detalhamento do serviço

O extrator lê o campo `DESCRIÇÃO DO SERVIÇO`, preserva o texto original e cria a coluna `Detalhamento` somente com as palavras-chave padronizadas:

- `DOM`, `Doméstico`, `Domestic` → `DOM`
- `LAND`, `Landside`, `Land Side` → `LAND`
- `Fast Pass`, `FastPass`, `Fast Track` → `Fast Pass`
- `M&A`, `Meet Assist`, `Meet & Assist`, `Meet and Assist` → `Meet & Assist`

Variações de maiúsculas, minúsculas, acentos, espaços, hífen e pequenos erros de OCR também são aceitas.
