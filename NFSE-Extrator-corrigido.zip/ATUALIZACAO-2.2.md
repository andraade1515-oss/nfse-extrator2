# Atualização 2.2 - Cancelamentos em lotes grandes

## Correção

- remove concorrência indevida no mesmo worker de OCR;
- identifica diretamente a tarja vermelha diagonal extensa;
- mantém OCR protegido em fila nos casos visuais menos evidentes;
- limita o paralelismo geral para preservar memória e estabilidade;
- garante que processar muitas notas tenha o mesmo resultado que processá-las separadamente.

## Validação

As notas 12666, 12670 e 12676 apresentam a tarja oficial vermelha de cancelamento e devem ser exportadas com `Cancelada = SIM`.
