import { useCallback, useMemo, useRef, useState } from "react";
import { exportToExcel } from "../lib/nfse/excel";
import { terminateOcr } from "../lib/nfse/ocr";
import { processPdfFile, runPool } from "../lib/nfse/processor";
import type { FailedFile, FileProgress, NfseRecord } from "../lib/nfse/types";

/**
 * Paralelismo automático com limite conservador. PDFs continuam sendo lidos
 * em paralelo, mas tarefas de OCR são serializadas internamente para garantir
 * que o tamanho do lote nunca altere o resultado.
 */
function resolveConcurrency(fileCount: number): number {
  const cores =
    typeof navigator !== "undefined" && navigator.hardwareConcurrency
      ? navigator.hardwareConcurrency
      : 4;
  return Math.max(2, Math.min(cores, 6, fileCount));
}

export interface BatchState {
  readonly total: number;
  readonly processed: number;
  readonly records: readonly NfseRecord[];
  readonly failures: readonly FailedFile[];
  readonly progressByFile: readonly FileProgress[];
  readonly running: boolean;
  readonly elapsedMs: number;
  readonly etaMs: number | null;
}

export function useNfseBatch() {
  const [state, setState] = useState<BatchState>({
    total: 0,
    processed: 0,
    records: [],
    failures: [],
    progressByFile: [],
    running: false,
    elapsedMs: 0,
    etaMs: null,
  });
  const cancelled = useRef(false);

  const reset = useCallback(() => {
    cancelled.current = true;
    setState({
      total: 0,
      processed: 0,
      records: [],
      failures: [],
      progressByFile: [],
      running: false,
      elapsedMs: 0,
      etaMs: null,
    });
  }, []);

  const start = useCallback(async (files: readonly File[]) => {
    if (files.length === 0) return;
    cancelled.current = false;
    const startedAt = performance.now();

    setState({
      total: files.length,
      processed: 0,
      records: [],
      failures: [],
      progressByFile: files.map((file) => ({
        arquivo: file.name,
        status: "pendente",
      })),
      running: true,
      elapsedMs: 0,
      etaMs: null,
    });

    const setFileStatus = (index: number, status: FileProgress["status"], detalhe?: string) => {
      setState((prev) => {
        const progressByFile = [...prev.progressByFile];
        progressByFile[index] = {
          ...progressByFile[index],
          status,
          detalhe,
        };
        return { ...prev, progressByFile };
      });
    };

    await runPool(files, resolveConcurrency(files.length), async (file, index) => {
      if (cancelled.current) return;
      setFileStatus(index, "processando");
      try {
        const record = await processPdfFile(file);
        setState((prev) => {
          const processed = prev.processed + 1;
          const elapsedMs = performance.now() - startedAt;
          return {
            ...prev,
            processed,
            records: [...prev.records, record],
            elapsedMs,
            etaMs: processed > 0 ? (elapsedMs / processed) * (prev.total - processed) : null,
          };
        });
        setFileStatus(
          index,
          record.camposFaltantes.length === 0 ? "ok" : "parcial",
          record.camposFaltantes.length > 0
            ? `Campos não identificados: ${record.camposFaltantes.join(", ")}`
            : undefined,
        );
      } catch (error) {
        const motivo = error instanceof Error ? error.message : "Erro desconhecido";
        setState((prev) => {
          const processed = prev.processed + 1;
          const elapsedMs = performance.now() - startedAt;
          return {
            ...prev,
            processed,
            failures: [...prev.failures, { arquivo: file.name, motivo }],
            elapsedMs,
            etaMs: processed > 0 ? (elapsedMs / processed) * (prev.total - processed) : null,
          };
        });
        setFileStatus(index, "erro", motivo);
      }
    });

    await terminateOcr();
    setState((prev) => ({ ...prev, running: false, etaMs: 0 }));
  }, []);

  const download = useCallback(async () => {
    if (state.records.length === 0 && state.failures.length === 0) return null;
    return exportToExcel(state.records, state.failures);
  }, [state.records, state.failures]);

  const percent = useMemo(
    () => (state.total === 0 ? 0 : Math.round((state.processed / state.total) * 100)),
    [state.processed, state.total],
  );

  /** Vazão média em PDFs por segundo. */
  const throughput = useMemo(
    () => (state.elapsedMs > 0 ? state.processed / (state.elapsedMs / 1000) : 0),
    [state.processed, state.elapsedMs],
  );

  return { state, percent, throughput, start, reset, download };
}
