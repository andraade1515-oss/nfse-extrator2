import { useMemo, useState, type InputHTMLAttributes } from "react";
import { useNfseBatch } from "./hooks/useNfseBatch";

export default function App() {
  const { state, percent, start, reset, download } = useNfseBatch();
  const [files, setFiles] = useState<File[]>([]);
  const [query, setQuery] = useState("");
  const folderInputProps = {
    webkitdirectory: "",
    directory: "",
  } as InputHTMLAttributes<HTMLInputElement>;

  const records = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return state.records;
    return state.records.filter((r) =>
      [r.arquivo, r.numero, r.emitente, r.tomador, r.cnpjEmitente, r.cnpjTomador, r.descricaoServico, r.tipoServico]
        .some((v) => v.toLowerCase().includes(q)),
    );
  }, [query, state.records]);

  function addFiles(input: FileList | null) {
    if (!input) return;
    const pdfs = Array.from(input).filter((f) => f.name.toLowerCase().endsWith(".pdf"));
    setFiles((prev) => [...prev, ...pdfs]);
  }

  async function processar() {
    if (!files.length || state.running) return;
    await start(files);
  }

  function limpar() {
    setFiles([]);
    setQuery("");
    reset();
  }

  return (
    <main className="page">
      <header className="header">
        <div>
          <span className="tag">EXTRATOR FISCAL</span>
          <h1>Extrator NFS-e</h1>
          <p>Projeto independente para leitura de NFS-e/DANFSe em PDF.</p>
        </div>
        <div className="safe">✓ Valor validado pelo campo oficial da NFS-e</div>
      </header>

      <section
        className="drop"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files); }}
      >
        <div className="icon">PDF</div>
        <h2>Selecione ou arraste suas notas fiscais</h2>
        <p>Você pode carregar vários PDFs de uma vez.</p>
        <label className="btn primary">
          Selecionar PDFs
          <input hidden type="file" accept="application/pdf,.pdf" multiple onChange={(e) => addFiles(e.target.files)} />
        </label>
        <label className="btn">
          Selecionar pasta
          <input {...folderInputProps} hidden type="file" accept="application/pdf,.pdf" multiple onChange={(e) => addFiles(e.target.files)} />
        </label>
        <small>PDF com texto: leitura direta. PDF escaneado: OCR automático.</small>
      </section>

      <section className="toolbar">
        <div><strong>{files.length}</strong> arquivo(s) selecionado(s)</div>
        <div className="buttons">
          <button className="btn" onClick={limpar} disabled={state.running}>Limpar</button>
          <button className="btn primary" onClick={processar} disabled={!files.length || state.running}>
            {state.running ? `Processando ${state.processed}/${state.total} (${percent}%)` : "Extrair NFS-e"}
          </button>
          <button className="btn excel" onClick={() => download()} disabled={!state.records.length || state.running}>Exportar Excel</button>
        </div>
      </section>

      {files.length > 0 && !state.records.length && (
        <section className="files">
          {files.map((f, i) => <div key={`${f.name}-${i}`}>{f.name}</div>)}
        </section>
      )}

      {state.records.length > 0 && (
        <section className="results">
          <div className="result-head">
            <div><h2>Resultado</h2><p>{state.records.length} nota(s) processada(s)</p></div>
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Filtrar resultado..." />
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th>Arquivo</th><th>NFS-e</th><th>Competência</th><th>Data</th>
                <th>Emitente</th><th>Tomador</th><th>Detalhamento</th><th>Descrição do serviço</th><th>Valor operação/serviço</th><th>Cancelada</th><th>Status</th>
              </tr></thead>
              <tbody>
                {records.map((r) => (
                  <tr key={r.arquivo}>
                    <td>{r.arquivo}</td>
                    <td>{r.numero}</td>
                    <td>{r.competencia}</td>
                    <td>{r.dataEmissao}</td>
                    <td>{r.emitente}<small>{r.cnpjEmitente}</small></td>
                    <td>{r.tomador}<small>{r.cnpjTomador}</small></td>
                    <td><strong>{r.tipoServico}</strong></td>
                    <td className="description">{r.descricaoServico}</td>
                    <td className="money">R$ {r.valorTotal}</td>
                    <td>{r.cancelada ? "SIM" : "NÃO"}</td>
                    <td><span className={r.camposFaltantes.length ? "status warn" : "status ok"}>{r.camposFaltantes.length ? "CONFERIR" : "OK"}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {state.failures.length > 0 && (
        <section className="errors"><strong>Arquivos com erro:</strong>{state.failures.map((f) => <div key={f.arquivo}>{f.arquivo}: {f.motivo}</div>)}</section>
      )}

      <section className="rule">
        <h3>Regra principal contra valores errados</h3>
        <p>O valor da nota só é aceito quando o extrator encontra <strong>VALOR DA OPERAÇÃO / SERVIÇO</strong> dentro do bloco <strong>VALOR TOTAL DA NFS-E</strong>. ISSQN, tributos, retenções, IBS/CBS, valor líquido e valores da descrição não são usados como valor da nota.</p>
        <p>O campo <strong>Detalhamento</strong> lê <strong>DESCRIÇÃO DO SERVIÇO</strong> e retorna somente as classificações padronizadas: <strong>DOM</strong>, <strong>LAND</strong>, <strong>Fast Pass</strong> e <strong>Meet &amp; Assist</strong>, incluindo variações semelhantes.</p>
      </section>
    </main>
  );
}
