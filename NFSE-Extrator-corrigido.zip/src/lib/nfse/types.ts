/**
 * Tipos compartilhados do pipeline de extração DANFSe v2.0.
 */

/** Valor usado quando um campo não pode ser determinado com segurança. */
export const NOT_FOUND = "NÃO IDENTIFICADO" as const;

/** Item textual posicionado (origem: camada de texto do PDF ou OCR). */
export interface PositionedItem {
  readonly text: string;
  /** Coordenada horizontal do início do item (unidades de página). */
  readonly x: number;
  /** Coordenada vertical (crescente de cima para baixo). */
  readonly y: number;
}

/** Linha reconstruída: itens ordenados horizontalmente. */
export interface Line {
  readonly y: number;
  readonly items: readonly PositionedItem[];
  /** Texto normalizado (maiúsculas, sem acentos, espaços colapsados). */
  readonly normalized: string;
}

/** Documento reconstruído (todas as páginas concatenadas). */
export interface DocumentLayout {
  readonly lines: readonly Line[];
  readonly rawText: string;
  readonly source: ExtractionSource;
}

export type ExtractionSource = "pdf-text" | "ocr" | "ocr-enhanced";

/** Registro final exportado para o Excel. */
export interface NfseRecord {
  readonly arquivo: string;
  readonly numero: string;
  readonly competencia: string;
  readonly dataEmissao: string;
  readonly emitente: string;
  readonly cnpjEmitente: string;
  readonly tomador: string;
  readonly cnpjTomador: string;
  /** Conteúdo textual do campo DESCRIÇÃO DO SERVIÇO. */
  readonly descricaoServico: string;
  /** Detalhamento padronizado contendo apenas as palavras-chave reconhecidas. */
  readonly tipoServico: string;
  readonly valorTotal: string;
  readonly origem: ExtractionSource;
  /** Verdadeiro quando o documento traz o carimbo/marca d'água de cancelamento. */
  readonly cancelada: boolean;

  /** Campos que ficaram como NÃO IDENTIFICADO. */
  readonly camposFaltantes: readonly string[];
}

export interface FailedFile {
  readonly arquivo: string;
  readonly motivo: string;
}

export type FileStatus = "pendente" | "processando" | "ok" | "parcial" | "erro";

export interface FileProgress {
  readonly arquivo: string;
  readonly status: FileStatus;
  readonly detalhe?: string;
}
