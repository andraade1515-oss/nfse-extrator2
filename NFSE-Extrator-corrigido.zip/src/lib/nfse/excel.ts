import type { FailedFile, NfseRecord } from "./types";

/** Nome padronizado: Relatorio_NFSE_YYYYMMDD_HHMM.xlsx */
export function buildReportFilename(date = new Date()): string {
  const pad = (value: number) => String(value).padStart(2, "0");
  const stamp =
    `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}` +
    `_${pad(date.getHours())}${pad(date.getMinutes())}`;
  return `Relatorio_NFSE_${stamp}.xlsx`;
}

/** Converte "141.783,44" para número (Excel guarda numérico de verdade). */
function toNumber(value: string): number | string {
  const match = value.match(/^\d{1,3}(?:\.\d{3})*,\d{2}$|^\d+,\d{2}$/);
  if (!match) return value;
  return Number(value.replace(/\./g, "").replace(",", "."));
}

export async function exportToExcel(
  records: readonly NfseRecord[],
  failures: readonly FailedFile[],
): Promise<string> {
  const XLSX = await import("xlsx");

  const rows = records.map((record) => ({
    "Número NFS-e": record.numero,
    Competência: record.competencia,
    "Data Emissão": record.dataEmissao,
    Emitente: record.emitente,
    "CNPJ Emitente": record.cnpjEmitente,
    Tomador: record.tomador,
    "CNPJ Tomador": record.cnpjTomador,
    "Descrição do Serviço": record.descricaoServico,
    Detalhamento: record.tipoServico,
    "Valor Total": toNumber(record.valorTotal),
    Cancelada: record.cancelada ? "SIM" : "NÃO",
    Arquivo: record.arquivo,
    Extração: record.origem,
  }));

  const workbook = XLSX.utils.book_new();
  const sheet = XLSX.utils.json_to_sheet(rows);
  sheet["!cols"] = [
    { wch: 14 },
    { wch: 12 },
    { wch: 20 },
    { wch: 40 },
    { wch: 20 },
    { wch: 40 },
    { wch: 20 },
    { wch: 70 },
    { wch: 18 },
    { wch: 16 },
    { wch: 11 },
    { wch: 30 },
    { wch: 14 },
  ];

  // Formato numérico brasileiro para a coluna de valor.
  for (let row = 0; row < rows.length; row += 1) {
    const address = XLSX.utils.encode_cell({ r: row + 1, c: 9 });
    const cell = sheet[address];
    if (cell && typeof cell.v === "number") cell.z = "#,##0.00";
  }

  XLSX.utils.book_append_sheet(workbook, sheet, "NFS-e");

  if (failures.length > 0) {
    const errorSheet = XLSX.utils.json_to_sheet(
      failures.map((failure) => ({
        Arquivo: failure.arquivo,
        Motivo: failure.motivo,
      })),
    );
    errorSheet["!cols"] = [{ wch: 40 }, { wch: 70 }];
    XLSX.utils.book_append_sheet(workbook, errorSheet, "Erros");
  }

  const filename = buildReportFilename();
  XLSX.writeFile(workbook, filename, { compression: true });
  return filename;
}
