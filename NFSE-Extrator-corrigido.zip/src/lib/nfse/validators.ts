import { normalize } from "./layout";

/** Valida dígitos verificadores de CNPJ. */
export function isValidCnpj(raw: string): boolean {
  const digits = raw.replace(/\D/g, "");
  if (digits.length !== 14) return false;
  if (/^(\d)\1{13}$/.test(digits)) return false;

  const calc = (length: number): number => {
    let weight = length - 7;
    let sum = 0;
    for (let i = 0; i < length; i += 1) {
      sum += Number(digits[i]) * weight;
      weight -= 1;
      if (weight < 2) weight = 9;
    }
    const rest = sum % 11;
    return rest < 2 ? 0 : 11 - rest;
  };

  return calc(12) === Number(digits[12]) && calc(13) === Number(digits[13]);
}

/** Valida dígitos verificadores de CPF. */
export function isValidCpf(raw: string): boolean {
  const digits = raw.replace(/\D/g, "");
  if (digits.length !== 11 || /^(\d)\1{10}$/.test(digits)) return false;
  const calc = (length: number): number => {
    let sum = 0;
    for (let i = 0; i < length; i += 1) {
      sum += Number(digits[i]) * (length + 1 - i);
    }
    const rest = (sum * 10) % 11;
    return rest === 10 ? 0 : rest;
  };
  return calc(9) === Number(digits[9]) && calc(10) === Number(digits[10]);
}

export function formatCnpj(raw: string): string {
  const d = raw.replace(/\D/g, "");
  if (d.length === 14) {
    return `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;
  }
  if (d.length === 11) {
    return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`;
  }
  return raw;
}

/** Aceita apenas documentos íntegros (CNPJ ou CPF). */
export function validateDocumento(raw: string): string | null {
  const digits = raw.replace(/\D/g, "");
  if (digits.length === 14 && isValidCnpj(digits)) return formatCnpj(digits);
  if (digits.length === 11 && isValidCpf(digits)) return formatCnpj(digits);
  return null;
}

/** Competência no formato MM/AAAA (aceita também dd/mm/aaaa -> mm/aaaa). */
export function validateCompetencia(raw: string): string | null {
  const compact = raw.replace(/\s/g, "");
  const monthYear = compact.match(/^(\d{2})\/(\d{4})$/);
  if (monthYear) {
    const month = Number(monthYear[1]);
    return month >= 1 && month <= 12 ? compact : null;
  }
  const fullDate = compact.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (fullDate) {
    const month = Number(fullDate[2]);
    return month >= 1 && month <= 12 ? `${fullDate[2]}/${fullDate[3]}` : null;
  }
  return null;
}

/** Data/hora de emissão: dd/mm/aaaa [hh:mm[:ss]]. */
export function validateDataEmissao(raw: string): string | null {
  const match = raw.match(/(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}:\d{2}(?::\d{2})?))?/);
  if (!match) return null;
  const day = Number(match[1]);
  const month = Number(match[2]);
  if (day < 1 || day > 31 || month < 1 || month > 12) return null;
  return match[4]
    ? `${match[1]}/${match[2]}/${match[3]} ${match[4]}`
    : `${match[1]}/${match[2]}/${match[3]}`;
}

/** Número da NFS-e: apenas dígitos, 1 a 15 posições. */
export function validateNumero(raw: string): string | null {
  const digits = raw.replace(/\D/g, "");
  return digits.length >= 1 && digits.length <= 15 ? digits : null;
}

/** Valor monetário no padrão brasileiro (1.234.567,89). */
export function validateValor(raw: string): string | null {
  const match = raw.replace(/\s/g, "").match(/^R?\$?(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2})$/);
  return match ? match[1] : null;
}

/** Nome empresarial plausível: >= 3 caracteres e sem cara de rótulo/valor. */
export function validateNome(raw: string): string | null {
  const value = raw.replace(/\s+/g, " ").trim();
  if (value.length < 3) return null;
  const normalized = normalize(value);
  if (/^[\d.,/-]+$/.test(normalized)) return null;
  const labelLike = ["NOME / NOME EMPRESARIAL", "MUNICIPIO", "CNPJ", "ENDERECO", "E-MAIL"];
  if (labelLike.some((label) => normalized === label)) return null;
  return value;
}
