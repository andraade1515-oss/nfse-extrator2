import { normalize } from "./layout";
import type { PdfDocument } from "./pdfText";

/**
 * Detecção de NFS-e cancelada.
 *
 * Ordem obrigatória (da verificação mais barata para a mais cara):
 *   1. texto já extraído (custo zero — reaproveita a leitura existente);
 *   2. metadados / dicionário do PDF (leitura de objetos, sem renderizar);
 *   3. OCR — somente quando o PDF não possui camada de texto.
 */

/** Radical usado para casar CANCELADA / CANCELADO / CANCELAMENTO. */
const CANCEL_TOKEN = "CANCELAD";

/** Termos-alvo (já normalizados) buscados no texto do PDF ou do OCR. */
const CANCEL_TERMS = ["CANCELADA", "CANCELAMENTO", "NF CANCELADA"] as const;

/** Similaridade mínima aceita para tolerar ruído de OCR ("CANCELAOA"). */
const MIN_SIMILARITY = 0.8;

/** Distância de Levenshtein (iterativa, duas linhas). */
function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i += 1) {
    const row = [i];
    for (let j = 1; j <= b.length; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      row[j] = Math.min(row[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    prev = row;
  }
  return prev[b.length];
}

function similarity(a: string, b: string): number {
  const max = Math.max(a.length, b.length);
  if (max === 0) return 1;
  return 1 - levenshtein(a, b) / max;
}

/**
 * Busca difusa (>= 80% de similaridade) por CANCELADA / CANCELAMENTO /
 * NF CANCELADA em um texto qualquer — tolera erros típicos de OCR.
 */
export function matchesCancelTerm(rawText: string): boolean {
  if (!rawText) return false;
  const text = normalize(rawText);
  if (text.includes(CANCEL_TOKEN)) return true;

  /*
   * O OCR de marca d'água costuma quebrar a palavra em pedaços
   * ("CA NC ELA DA"). Comparamos também o texto compactado (sem separadores)
   * em janelas deslizantes do tamanho de cada termo-alvo.
   */
  const compact = text.replace(/[^A-Z0-9]/g, "");
  if (compact.length >= 6) {
    for (const term of CANCEL_TERMS) {
      const target = term.replace(/[^A-Z0-9]/g, "");
      for (let size = target.length - 1; size <= target.length + 1; size += 1) {
        if (size < 6) continue;
        for (let i = 0; i + size <= compact.length; i += 1) {
          if (similarity(compact.slice(i, i + size), target) >= MIN_SIMILARITY) {
            return true;
          }
        }
      }
    }
  }

  // Janelas de 1 e 2 palavras comparadas com cada termo-alvo.
  const words = text.split(/[^A-Z0-9]+/).filter(Boolean);
  for (let i = 0; i < words.length; i += 1) {
    const candidates = [words[i]];
    if (i + 1 < words.length) candidates.push(`${words[i]} ${words[i + 1]}`);
    for (const candidate of candidates) {
      if (candidate.length < 6) continue;
      for (const term of CANCEL_TERMS) {
        if (Math.abs(candidate.length - term.length) > 3) continue;
        if (similarity(candidate, term) >= MIN_SIMILARITY) return true;
      }
    }
  }
  return false;
}

/** Etapa 1: procura o carimbo no texto já disponível (nenhum custo extra). */
export function hasCanceladaInText(rawText: string): boolean {
  return matchesCancelTerm(rawText);
}

/**
 * Etapa 2: metadados do documento (título, assunto, palavras-chave e campos
 * customizados). Muitos emissores marcam o cancelamento nesses campos ou no
 * nome do XObject/camada da marca d'água.
 */
export async function hasCanceladaInMetadata(pdf: PdfDocument): Promise<boolean> {
  try {
    const metadata = await pdf.getMetadata();
    const info = (metadata.info ?? {}) as Record<string, unknown>;
    for (const value of Object.values(info)) {
      if (typeof value === "string" && normalize(value).includes(CANCEL_TOKEN)) {
        return true;
      }
    }
    const xmpSource = metadata.metadata as { getAll?: () => Record<string, unknown> } | undefined;
    const xmp = xmpSource?.getAll?.();
    if (xmp) {
      for (const value of Object.values(xmp)) {
        if (typeof value === "string" && normalize(value).includes(CANCEL_TOKEN)) {
          return true;
        }
      }
    }

    // Camadas opcionais (OCG): a marca d'água costuma virar uma camada nomeada.
    const optional = (await pdf.getOptionalContentConfig?.()) as
      { getGroups?: () => Record<string, { name?: string | null }> } | undefined;
    const groups = optional?.getGroups?.();

    if (groups) {
      for (const group of Object.values(groups)) {
        if (group?.name && normalize(group.name).includes(CANCEL_TOKEN)) {
          return true;
        }
      }
    }
  } catch {
    // Metadados ausentes ou ilegíveis nunca devem interromper o pipeline.
  }
  return false;
}

/** Resultado da inspeção de objetos gráficos da 1ª página. */
export type GraphicsCancelSignal = "cancelada" | "suspeita" | "limpo";

/** Um pixel é "vermelho de marca d'água" quando R domina G/B com folga. */
function isWatermarkRed(r: number, g: number, b: number): boolean {
  return r > 120 && r - g > 45 && r - b > 45;
}

/**
 * Etapa 2: inspeciona os objetos gráficos da PRIMEIRA página (operator list),
 * sem renderizar nada.
 *
 * - "cancelada": algum nome de XObject/Form/imagem, anotação (carimbo) ou
 *   string desenhada contém CANCELAD — evidência direta da marca d'água.
 * - "suspeita": a página pinta em vermelho translúcido (padrão típico da
 *   marca d'água diagonal). Só nesse caso vale a pena renderizar + OCR.
 * - "limpo": nenhum indício; nenhum custo adicional é gasto.
 */
export async function inspectCanceladaGraphics(pdf: PdfDocument): Promise<GraphicsCancelSignal> {
  try {
    const page = await pdf.getPage(1);
    try {
      const annotations = (await page.getAnnotations()) as Array<Record<string, unknown>>;
      for (const annotation of annotations) {
        for (const key of ["contents", "title", "subject", "alternativeText"]) {
          const value = annotation[key];
          if (typeof value === "string" && normalize(value).includes(CANCEL_TOKEN)) {
            return "cancelada";
          }
        }
      }

      const operatorList = await page.getOperatorList();
      const args = operatorList.argsArray as unknown[][];
      let redFill = false;
      let translucent = false;

      for (const entry of args) {
        if (!entry) continue;
        for (const arg of entry) {
          if (typeof arg === "string") {
            // Nomes de XObject/Form ("CANCELADA", "wm_cancelada"...) e strings.
            if (normalize(arg).includes(CANCEL_TOKEN)) return "cancelada";
          } else if (Array.isArray(arg)) {
            // Texto desenhado (showText) chega como lista de glifos.
            const text = arg
              .map((glyph) =>
                typeof glyph === "string"
                  ? glyph
                  : typeof (glyph as { unicode?: string })?.unicode === "string"
                    ? (glyph as { unicode: string }).unicode
                    : "",
              )
              .join("");
            if (text && normalize(text).includes(CANCEL_TOKEN)) {
              return "cancelada";
            }
          } else if (arg && typeof arg === "object") {
            const record = arg as Record<string, unknown>;
            // Estado gráfico: opacidade de preenchimento (marca translúcida).
            const ca = record.ca ?? record.CA;
            if (typeof ca === "number" && ca < 0.95) translucent = true;
          } else if (typeof arg === "number" && entry.length === 3) {
            // Possível cor RGB em 0..1 (setFillRGBColor normalizado).
            const [r, g, b] = entry as number[];
            if ([r, g, b].every((v) => typeof v === "number" && v >= 0 && v <= 1)) {
              if (isWatermarkRed(r * 255, g * 255, b * 255)) redFill = true;
            }
            break;
          }
        }
      }

      // pdf.js também expõe cores já convertidas para inteiros 0..255.
      if (!redFill) {
        for (const entry of args) {
          if (!Array.isArray(entry)) continue;
          const [r, g, b] = entry as number[];
          if (
            typeof r === "number" &&
            typeof g === "number" &&
            typeof b === "number" &&
            entry.length === 3 &&
            isWatermarkRed(r, g, b)
          ) {
            redFill = true;
            break;
          }
        }
      }

      return redFill || translucent ? "suspeita" : "limpo";
    } finally {
      page.cleanup();
    }
  } catch {
    return "limpo";
  }
}

/**
 * Confirmação visual barata: renderiza a 1ª página em baixa resolução e mede
 * a área coberta por vermelho translúcido. Serve de porteiro do OCR.
 */
export function hasLargeRedArea(canvas: HTMLCanvasElement): boolean {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return false;
  const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height);
  let red = 0;
  // Amostragem 1:4 — precisão suficiente e 4x mais rápido.
  for (let i = 0; i < data.length; i += 16) {
    if (isWatermarkRed(data[i], data[i + 1], data[i + 2])) red += 1;
  }
  const sampled = Math.ceil(data.length / 16);
  return red / sampled > 0.004;
}
