import { matchesCancelTerm } from "./cancelled";
import { buildLines, linesToText } from "./layout";
import { renderPageToCanvas, type PdfDocument } from "./pdfText";

import type { DocumentLayout, PositionedItem } from "./types";

type TesseractWorker = Awaited<ReturnType<typeof import("tesseract.js").createWorker>>;

let workerPromise: Promise<TesseractWorker> | null = null;

/**
 * O Tesseract mantém estado interno (incluindo os parâmetros de segmentação)
 * e não aceita chamadas recognize/setParameters concorrentes no mesmo worker.
 * Em lotes grandes, o antigo acesso paralelo podia misturar duas notas e
 * deixar uma marca de cancelamento passar despercebida.
 */
let ocrQueue: Promise<void> = Promise.resolve();

async function withOcrWorker<T>(task: (worker: TesseractWorker) => Promise<T>): Promise<T> {
  const previous = ocrQueue;
  let release!: () => void;
  ocrQueue = new Promise<void>((resolve) => {
    release = resolve;
  });

  await previous;
  try {
    return await task(await getWorker());
  } finally {
    release();
  }
}

/** Worker OCR único e reutilizado (criação é cara). */
async function getWorker(): Promise<TesseractWorker> {
  if (!workerPromise) {
    workerPromise = (async () => {
      const { createWorker } = await import("tesseract.js");
      return createWorker("por");
    })();
  }
  return workerPromise;
}

export async function terminateOcr(): Promise<void> {
  if (!workerPromise) return;
  const worker = await workerPromise;
  workerPromise = null;
  await worker.terminate();
}

/** Pré-processamento: escala de cinza, contraste, binarização e sharpening. */
function enhance(canvas: HTMLCanvasElement): HTMLCanvasElement {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return canvas;
  const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = image.data;

  // 1) Escala de cinza + histograma para limiar de Otsu.
  const gray = new Uint8ClampedArray(canvas.width * canvas.height);
  const histogram = new Array<number>(256).fill(0);
  for (let i = 0, p = 0; i < data.length; i += 4, p += 1) {
    const value = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
    gray[p] = value;
    histogram[value] += 1;
  }

  const total = gray.length;
  let sum = 0;
  for (let t = 0; t < 256; t += 1) sum += t * histogram[t];
  let sumB = 0;
  let weightB = 0;
  let maxVariance = -1;
  let threshold = 128;
  for (let t = 0; t < 256; t += 1) {
    weightB += histogram[t];
    if (weightB === 0) continue;
    const weightF = total - weightB;
    if (weightF === 0) break;
    sumB += t * histogram[t];
    const meanB = sumB / weightB;
    const meanF = (sum - sumB) / weightF;
    const variance = weightB * weightF * (meanB - meanF) ** 2;
    if (variance > maxVariance) {
      maxVariance = variance;
      threshold = t;
    }
  }

  // 2) Binarização com pequena margem de segurança (remove ruído leve).
  for (let p = 0, i = 0; p < gray.length; p += 1, i += 4) {
    const value = gray[p] > threshold ? 255 : 0;
    data[i] = value;
    data[i + 1] = value;
    data[i + 2] = value;
    data[i + 3] = 255;
  }

  ctx.putImageData(image, 0, 0);
  return canvas;
}

interface OcrLineWord {
  readonly text: string;
  readonly bbox: { x0: number; y0: number };
}

interface Rect {
  readonly left: number;
  readonly top: number;
  readonly width: number;
  readonly height: number;
}

/**
 * Regiões de interesse do DANFSe v2.0 (fração da altura da página):
 * cabeçalho (número/competência/emissão), partes (emitente/tomador) e
 * bloco de valores. A discriminação dos serviços — a maior área da página —
 * é ignorada, pois nenhum campo requerido vive nela.
 */
const ROI_BANDS: ReadonlyArray<{ start: number; end: number }> = [
  { start: 0, end: 0.5 },
  { start: 0.62, end: 1 },
];

/** Recorta uma faixa da página em um canvas próprio. */
function cropBand(source: HTMLCanvasElement, rect: Rect): HTMLCanvasElement {
  const band = document.createElement("canvas");
  band.width = rect.width;
  band.height = rect.height;
  const ctx = band.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Não foi possível recortar a região do PDF.");
  ctx.drawImage(
    source,
    rect.left,
    rect.top,
    rect.width,
    rect.height,
    0,
    0,
    rect.width,
    rect.height,
  );
  return band;
}

/** Executa OCR sobre uma região já renderizada. */
async function recognizeCanvas(
  canvas: HTMLCanvasElement,
  yOffset: number,
): Promise<PositionedItem[]> {
  const result = await withOcrWorker((worker) =>
    worker.recognize(canvas, {}, { blocks: true }),
  );
  const items: PositionedItem[] = [];

  const blocks = (result.data.blocks ?? []) as Array<{
    paragraphs?: Array<{ lines?: Array<{ words?: OcrLineWord[] }> }>;
  }>;

  for (const block of blocks) {
    for (const paragraph of block.paragraphs ?? []) {
      for (const line of paragraph.lines ?? []) {
        for (const word of line.words ?? []) {
          if (!word.text?.trim()) continue;
          items.push({
            text: word.text,
            x: word.bbox.x0,
            y: yOffset + word.bbox.y0,
          });
        }
      }
    }
  }
  return items;
}

/**
 * Camadas 2 e 3: OCR do PDF renderizado, com pré-processamento opcional.
 * Apenas a primeira página é lida (todos os campos requeridos do DANFSe v2.0
 * estão nela) e apenas nas regiões de interesse.
 */
export async function extractViaOcr(
  pdf: PdfDocument,
  options: { enhanced: boolean },
): Promise<DocumentLayout> {
  const items: PositionedItem[] = [];
  const scale = options.enhanced ? 3 : 2;

  const canvas = await renderPageToCanvas(pdf, 1, scale);
  const prepared = options.enhanced ? enhance(canvas) : canvas;

  for (const region of ROI_BANDS) {
    const top = Math.floor(prepared.height * region.start);
    const height = Math.floor(prepared.height * region.end) - top;
    if (height <= 0) continue;
    const band = cropBand(prepared, {
      left: 0,
      top,
      width: prepared.width,
      height,
    });
    items.push(...(await recognizeCanvas(band, top)));
    band.width = 0;
    band.height = 0;
  }

  prepared.width = 0;
  prepared.height = 0;

  // OCR tem variação vertical maior que a camada de texto nativa.
  const lines = buildLines(items, options.enhanced ? 14 : 10);
  return {
    lines,
    rawText: linesToText(lines),
    source: options.enhanced ? "ocr-enhanced" : "ocr",
  };
}

/** Um pixel pertence ao carimbo quando o vermelho domina verde/azul. */
function isStampPixel(r: number, g: number, b: number): boolean {
  return r > 130 && r - g > 25 && r - b > 25;
}

/**
 * Isola a marca d'água: mantém apenas os pixels avermelhados (preto sobre
 * branco). Remove todo o conteúdo preto da nota, deixando somente o carimbo —
 * é o que torna o OCR do texto diagonal viável.
 */
function isolateStamp(
  canvas: HTMLCanvasElement,
): {
  mask: HTMLCanvasElement;
  coverage: number;
  widthSpan: number;
  heightSpan: number;
} | null {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = image.data;
  let stamp = 0;
  let minX = canvas.width;
  let maxX = -1;
  let minY = canvas.height;
  let maxY = -1;
  for (let i = 0; i < data.length; i += 4) {
    const hit = isStampPixel(data[i], data[i + 1], data[i + 2]);
    const value = hit ? 0 : 255;
    if (hit) {
      stamp += 1;
      const pixel = i / 4;
      const x = pixel % canvas.width;
      const y = Math.floor(pixel / canvas.width);
      minX = Math.min(minX, x);
      maxX = Math.max(maxX, x);
      minY = Math.min(minY, y);
      maxY = Math.max(maxY, y);
    }
    data[i] = value;
    data[i + 1] = value;
    data[i + 2] = value;
    data[i + 3] = 255;
  }
  ctx.putImageData(image, 0, 0);
  return {
    mask: canvas,
    coverage: stamp / (data.length / 4),
    widthSpan: stamp > 0 ? (maxX - minX + 1) / canvas.width : 0,
    heightSpan: stamp > 0 ? (maxY - minY + 1) / canvas.height : 0,
  };
}

/** Rotaciona um canvas em graus, com fundo branco. */
function rotateCanvas(source: HTMLCanvasElement, degrees: number): HTMLCanvasElement {
  const radians = (degrees * Math.PI) / 180;
  const sin = Math.abs(Math.sin(radians));
  const cos = Math.abs(Math.cos(radians));
  const width = Math.ceil(source.width * cos + source.height * sin);
  const height = Math.ceil(source.width * sin + source.height * cos);
  const target = document.createElement("canvas");
  target.width = width;
  target.height = height;
  const ctx = target.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas indisponível para rotação.");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);
  ctx.translate(width / 2, height / 2);
  ctx.rotate(radians);
  ctx.drawImage(source, -source.width / 2, -source.height / 2);
  return target;
}

/** Cobertura mínima de pixels avermelhados para valer a pena rodar OCR. */
const MIN_STAMP_COVERAGE = 0.004;

/**
 * Uma tarja oficial grande cobre uma faixa diagonal da página inteira.
 * Este sinal geométrico é mais confiável e muito mais rápido que OCR.
 * Os limites altos evitam confundir um logotipo ou texto vermelho isolado.
 */
function isDefiniteLargeStamp(
  signal: { coverage: number; widthSpan: number; heightSpan: number },
): boolean {
  return signal.coverage >= 0.01 && signal.widthSpan >= 0.45 && signal.heightSpan >= 0.55;
}

/**
 * Detecção híbrida de cancelamento:
 *   1) renderiza SOMENTE a 1ª página a 150 DPI;
 *   2) isola os pixels do carimbo (marca d'água vermelha);
 *   3) roda OCR na máscara em algumas rotações (o carimbo é diagonal),
 *      procurando CANCELADA / CANCELAMENTO / NF CANCELADA com fuzzy >= 80%.
 * Erros de OCR são silenciosos: o resultado padrão é `false`.
 */
export async function ocrHasCancelada(pdf: PdfDocument): Promise<boolean> {
  let canvas: HTMLCanvasElement | null = null;
  try {
    canvas = await renderPageToCanvas(pdf, 1, 150 / 72);
    const isolated = isolateStamp(canvas);
    if (!isolated || isolated.coverage < MIN_STAMP_COVERAGE) return false;

    // As notas canceladas da prefeitura trazem uma marca vermelha diagonal
    // extensa. Esse teste não depende do OCR e permanece estável em lotes.
    if (isDefiniteLargeStamp(isolated)) return true;

    return await withOcrWorker(async (worker) => {
      await worker.setParameters({ tessedit_pageseg_mode: "6" as never });
      try {
        for (const angle of [-45, 45, 0]) {
          const rotated = angle === 0 ? isolated.mask : rotateCanvas(isolated.mask, angle);
          try {
            const result = await worker.recognize(rotated);
            if (matchesCancelTerm(result.data.text ?? "")) return true;
          } finally {
            if (rotated !== isolated.mask) {
              rotated.width = 0;
              rotated.height = 0;
            }
          }
        }
      } finally {
        await worker.setParameters({ tessedit_pageseg_mode: "3" as never });
      }
      return false;
    });
  } catch (error) {
    console.warn("Falha ao verificar cancelamento por OCR:", error);
    return false;
  } finally {
    if (canvas) {
      canvas.width = 0;
      canvas.height = 0;
    }
  }
}
