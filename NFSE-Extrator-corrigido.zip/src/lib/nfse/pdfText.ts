import { buildLines, linesToText, normalize } from "./layout";
import type { DocumentLayout, PositionedItem } from "./types";

/**
 * Carrega o pdf.js somente no browser (evita SSR e reduz o bundle inicial).
 */
async function loadPdfjs() {
  const pdfjs = await import("pdfjs-dist");
  const workerUrl = (await import("pdfjs-dist/build/pdf.worker.mjs?url")).default;
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
  return pdfjs;
}

export type PdfDocument = Awaited<
  ReturnType<Awaited<ReturnType<typeof loadPdfjs>>["getDocument"]>["promise"]
>;

export async function openPdf(data: ArrayBuffer): Promise<PdfDocument> {
  const pdfjs = await loadPdfjs();
  return pdfjs.getDocument({ data }).promise;
}

/**
 * Camada 1: extração direta da camada de texto do PDF.
 * Retorna null quando o PDF não possui texto útil (provável PDF-imagem).
 */
export async function extractTextLayer(pdf: PdfDocument): Promise<DocumentLayout | null> {
  const items: PositionedItem[] = [];
  let pageOffset = 0;

  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const viewport = page.getViewport({ scale: 1 });
    const content = await page.getTextContent();

    for (const item of content.items) {
      if (!("str" in item) || typeof item.str !== "string") continue;
      if (item.str.trim().length === 0) continue;
      const transform = item.transform as number[];
      items.push({
        text: item.str,
        x: transform[4],
        // pdf.js usa origem no rodapé; invertemos para leitura topo->base.
        y: pageOffset + (viewport.height - transform[5]),
      });
    }
    pageOffset += viewport.height + 50;
    page.cleanup();
  }

  const lines = buildLines(items);
  const rawText = linesToText(lines);

  // Heurística: DANFSe legítima sempre traz estes rótulos na camada de texto.
  if (!normalize(rawText).includes("NFS-E") || rawText.length < 200) {
    return null;
  }

  return { lines, rawText, source: "pdf-text" };
}

/** Renderiza uma página como canvas para OCR. */
export async function renderPageToCanvas(
  pdf: PdfDocument,
  pageNumber: number,
  scale: number,
): Promise<HTMLCanvasElement> {
  const page = await pdf.getPage(pageNumber);
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("Não foi possível criar o contexto do canvas.");
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, canvas.width, canvas.height);
  await page.render({ canvas, canvasContext: context, viewport }).promise;
  page.cleanup();
  return canvas;
}
