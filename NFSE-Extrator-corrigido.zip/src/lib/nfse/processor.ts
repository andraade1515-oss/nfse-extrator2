import { hasCanceladaInMetadata, hasCanceladaInText, inspectCanceladaGraphics } from "./cancelled";

import { extractViaOcr, ocrHasCancelada } from "./ocr";
import { parseDanfse } from "./parser";
import { extractTextLayer, openPdf } from "./pdfText";
import type { DocumentLayout, NfseRecord } from "./types";

export interface ProcessOutcome {
  readonly record: NfseRecord;
}

/**
 * Cache por conteúdo: PDFs idênticos (mesmo hash) não são reprocessados.
 * Guardamos o registro sem o nome do arquivo, aplicado a cada reuso.
 */
const contentCache = new Map<string, Omit<NfseRecord, "arquivo">>();

export function clearProcessorCache(): void {
  contentCache.clear();
}

async function hashBuffer(buffer: ArrayBuffer): Promise<string | null> {
  if (!globalThis.crypto?.subtle) return null;
  try {
    const digest = await crypto.subtle.digest("SHA-256", buffer);
    return Array.from(new Uint8Array(digest))
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
  } catch {
    return null;
  }
}

/** Log estruturado por PDF (método, tempo, OCR, campos). */
function logFile(record: NfseRecord, usedOcr: boolean, startedAt: number): void {
  const seconds = ((performance.now() - startedAt) / 1000).toFixed(2);
  const lines = [
    `PDF: ${record.arquivo}`,
    `Método: ${usedOcr ? "OCR (PDF sem camada de texto)" : "Texto pesquisável"}`,
    `Tempo: ${seconds} segundos`,
    `OCR: ${usedOcr ? "Sim" : "Não"}`,
    `Cancelada: ${record.cancelada ? "Sim" : "Não"}`,
    "Campos encontrados:",
  ];
  const faltantes = new Map(
    record.camposFaltantes.map((entry) => {
      const [campo, ...rest] = entry.split(":");
      return [campo.trim(), rest.join(":").trim()];
    }),
  );
  const campos: Array<[string, string]> = [
    ["Número", record.numero],
    ["Competência", record.competencia],
    ["Data", record.dataEmissao],
    ["Emitente", record.emitente],
    ["CNPJ Emitente", record.cnpjEmitente],
    ["Tomador", record.tomador],
    ["CNPJ Tomador", record.cnpjTomador],
    ["Descrição do Serviço", record.descricaoServico],
    ["Detalhamento", record.tipoServico],
    ["Valor", record.valorTotal],
  ];
  for (const [label] of campos) {
    const motivo =
      faltantes.get(label) ??
      faltantes.get(label === "Número" ? "Número NFS-e" : label) ??
      faltantes.get(label === "Data" ? "Data Emissão" : label) ??
      faltantes.get(label === "Valor" ? "Valor Total" : label);
    lines.push(motivo ? `✗ ${label} — Motivo: ${motivo}` : `✓ ${label}`);
  }
  console.info(lines.join("\n"));
}

/**
 * Pipeline: abre o PDF **uma única vez**, verifica a camada de texto e só
 * recorre ao OCR (1ª página, por regiões) quando não há texto pesquisável.
 */
export async function processPdfFile(file: File): Promise<NfseRecord> {
  const startedAt = performance.now();
  const buffer = await file.arrayBuffer();

  const hash = await hashBuffer(buffer);
  if (hash) {
    const cached = contentCache.get(hash);
    if (cached) {
      const record = { ...cached, arquivo: file.name };
      logFile(record, cached.origem !== "pdf-text", startedAt);
      return record;
    }
  }

  const pdf = await openPdf(buffer);

  try {
    // 1) Camada de texto: se existir, é a única passagem feita no arquivo.
    let layout: DocumentLayout | null = await extractTextLayer(pdf);
    let usedOcr = false;

    // 2) Sem texto pesquisável -> OCR da 1ª página, regiões de interesse.
    if (!layout) {
      usedOcr = true;
      layout = await extractViaOcr(pdf, { enhanced: false });
      let parsedOcr = parseDanfse(layout);
      if (!parsedOcr.confident) {
        const enhanced = await extractViaOcr(pdf, { enhanced: true });
        const parsedEnhanced = parseDanfse(enhanced);
        if (
          parsedEnhanced.record.camposFaltantes.length < parsedOcr.record.camposFaltantes.length
        ) {
          layout = enhanced;
          parsedOcr = parsedEnhanced;
        }
      }
    }

    if (!layout) {
      throw new Error(
        "Não foi possível extrair texto do PDF (arquivo vazio, protegido ou corrompido).",
      );
    }

    // Cancelamento: texto já lido -> metadados/camadas -> objetos gráficos da
    // 1ª página (sem renderizar) -> OCR híbrido da 1ª página a 150 DPI, apenas
    // procurando CANCELADA/CANCELAMENTO com correspondência difusa.
    let cancelada = hasCanceladaInText(layout.rawText);
    if (!cancelada) cancelada = await hasCanceladaInMetadata(pdf);
    if (!cancelada) {
      const signal = await inspectCanceladaGraphics(pdf);
      cancelada = signal === "cancelada" ? true : await ocrHasCancelada(pdf);
    }

    const record: NfseRecord = {
      ...parseDanfse(layout).record,
      arquivo: file.name,
      origem: layout.source,
      cancelada,
    };

    if (hash) {
      const { arquivo: _ignored, ...cacheable } = record;
      contentCache.set(hash, cacheable);
    }
    logFile(record, usedOcr, startedAt);
    return record;
  } finally {
    await pdf.cleanup();
    await pdf.loadingTask.destroy();
  }
}

/** Executa tarefas com um limite de paralelismo (lotes de milhares de PDFs). */
export async function runPool<T>(
  items: readonly T[],
  concurrency: number,
  task: (item: T, index: number) => Promise<void>,
): Promise<void> {
  let cursor = 0;
  const workers = Array.from(
    { length: Math.max(1, Math.min(concurrency, items.length)) },
    async () => {
      while (cursor < items.length) {
        const index = cursor;
        cursor += 1;
        await task(items[index], index);
      }
    },
  );
  await Promise.all(workers);
}
