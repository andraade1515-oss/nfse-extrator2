import { normalize } from "./layout";
import type { DocumentLayout, Line, NfseRecord } from "./types";
import { NOT_FOUND } from "./types";
import {
  validateCompetencia,
  validateDataEmissao,
  validateDocumento,
  validateNome,
  validateNumero,
  validateValor,
} from "./validators";

/** Distância de Levenshtein (limitada, usada para tolerar ruído de OCR). */
function levenshtein(a: string, b: string): number {
  const previous = new Array<number>(b.length + 1);
  for (let j = 0; j <= b.length; j += 1) previous[j] = j;
  for (let i = 1; i <= a.length; i += 1) {
    let diagonal = previous[0];
    previous[0] = i;
    for (let j = 1; j <= b.length; j += 1) {
      const temp = previous[j];
      previous[j] = Math.min(
        previous[j] + 1,
        previous[j - 1] + 1,
        diagonal + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
      diagonal = temp;
    }
  }
  return previous[b.length];
}

function similar(a: string, b: string, minRatio = 0.86): boolean {
  if (a === b) return true;
  const longest = Math.max(a.length, b.length);
  if (longest === 0) return false;
  if (Math.abs(a.length - b.length) / longest > 1 - minRatio) return false;
  return 1 - levenshtein(a, b) / longest >= minRatio;
}

interface LabelHit {
  readonly lineIndex: number;
  /** X inicial do rótulo. */
  readonly x: number;
  /** X do próximo rótulo na mesma linha (limite da coluna). */
  readonly nextX: number;
}

/**
 * Procura um rótulo dentro de uma linha, acumulando itens adjacentes
 * (o PDF pode quebrar "NOME / NOME EMPRESARIAL" em vários itens).
 */
function matchLabelInLine(line: Line, label: string): LabelHit | null {
  const { items } = line;
  for (let start = 0; start < items.length; start += 1) {
    let acc = "";
    for (let end = start; end < items.length && end < start + 8; end += 1) {
      acc = normalize(`${acc} ${items[end].text}`);
      if (acc.length > label.length + 6) break;
      if (similar(acc, label)) {
        const next = items[end + 1];
        return {
          lineIndex: -1,
          x: items[start].x,
          nextX: next ? next.x : Number.POSITIVE_INFINITY,
        };
      }
    }
  }
  return null;
}

function findLabel(
  lines: readonly Line[],
  label: string,
  from = 0,
  to = lines.length,
): LabelHit | null {
  const target = normalize(label);
  for (let index = from; index < Math.min(to, lines.length); index += 1) {
    const hit = matchLabelInLine(lines[index], target);
    if (hit) return { ...hit, lineIndex: index };
  }
  return null;
}

/**
 * Lê o valor da coluna do rótulo: percorre as próximas linhas e junta
 * os itens que pertencem à mesma faixa horizontal.
 */
function readColumnValue(
  lines: readonly Line[],
  hit: LabelHit,
  lookahead = 2,
  tolerance = 20,
): string | null {
  for (
    let index = hit.lineIndex + 1;
    index <= hit.lineIndex + lookahead && index < lines.length;
    index += 1
  ) {
    const parts = lines[index].items.filter(
      (item) =>
        item.x >= hit.x - tolerance &&
        (hit.nextX === Number.POSITIVE_INFINITY || item.x < hit.nextX - tolerance),
    );
    if (parts.length === 0) continue;
    const value = parts
      .map((p) => p.text)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (value.length > 0) return value;
  }
  return null;
}

/**
 * Uma linha inicia a seção quando o texto dela (ou apenas o primeiro item,
 * a célula da esquerda) começa com o título. No layout DANFSe atual o título
 * fica na mesma linha dos valores ("TOMADOR / ADQUIRENTE  632.191.072-49"),
 * enquanto no layout antigo a linha continha só o título.
 */
function lineStartsSection(line: Line, title: string): boolean {
  const value = line.normalized;
  if (similar(value, title)) return true;
  if (value.startsWith(title)) return true;
  const first = line.items[0] ? normalize(line.items[0].text) : "";
  return first.length >= 6 && (first === title || similar(first, title));
}

/** Localiza o índice da linha que inicia uma seção do DANFSe. */
function findSection(lines: readonly Line[], title: string, from = 0): number | null {
  const target = normalize(title);
  for (let index = from; index < lines.length; index += 1) {
    if (lineStartsSection(lines[index], target)) return index;
  }
  return null;
}

const SECTION_TITLES = [
  "EMITENTE DA NFS-E",
  "PRESTADOR / FORNECEDOR",
  "PRESTADOR",
  "TOMADOR / ADQUIRENTE",
  "DESTINATARIO DA OPERACAO",
  "INTERMEDIARIO DO SERVICO",
  "INTERMEDIARIO DA OPERACAO",
  "SERVICO PRESTADO",
  "TIPO DE TRIBUTACAO DO ISSQN",
  "TIPO TRIBUTACAO (ISSQN)",
  "TRIBUTACAO MUNICIPAL (ISSQN)",
  "TRIBUTACAO FEDERAL (EXCETO CBS)",
  "TRIBUTACAO IBS / CBS",
  "VALOR TOTAL DA NFS-E",
  "TOTAIS APROXIMADOS DOS TRIBUTOS",
  "INFORMACOES COMPLEMENTARES",
];

/** Fim da seção = próxima seção conhecida. */
function sectionEnd(lines: readonly Line[], start: number): number {
  for (let index = start + 1; index < lines.length; index += 1) {
    if (SECTION_TITLES.some((title) => lineStartsSection(lines[index], title))) return index;
  }
  return lines.length;
}

interface Block {
  readonly start: number;
  readonly end: number;
}

/** Localiza um bloco (título -> próxima seção conhecida). */
function findBlock(lines: readonly Line[], title: string, from = 0): Block | null {
  const start = findSection(lines, title, from);
  if (start === null) return null;
  return { start, end: sectionEnd(lines, start) };
}

const DOC_PATTERN =
  /\d{2}[.\s]?\d{3}[.\s]?\d{3}\/?\d{4}[-\s]?\d{2}|\d{3}[.\s]?\d{3}[.\s]?\d{3}[-\s]?\d{2}/;

/**
 * Busca o primeiro CNPJ/CPF **dentro do bloco**, a partir do rótulo
 * "CNPJ / CPF / NIF". Nunca varre a página inteira.
 */
function findDocumentoInBlock(lines: readonly Line[], block: Block): string | null {
  // 0) Layout atual: o documento está na MESMA linha do título da seção
  //    (o rótulo "CNPJ / CPF / NIF" fica na linha acima).
  const titleLine = lines[block.start];
  if (titleLine) {
    for (const item of titleLine.items.slice(1)) {
      const match = DOC_PATTERN.exec(item.text);
      const documento = match ? validateDocumento(match[0]) : null;
      if (documento) return documento;
    }
  }

  const labelHit = findLabel(lines, "CNPJ / CPF / NIF", block.start + 1, block.end);
  if (!labelHit) return null;

  // 1) Caminho preferencial: coluna alinhada ao rótulo.
  const column = readColumnValue(lines, labelHit);
  const fromColumn = column ? validateDocumento(column) : null;
  if (fromColumn) return fromColumn;

  // 2) Fallback: primeira ocorrência de documento nas linhas seguintes,
  //    ainda restritas ao bloco (tolera desalinhamento de colunas/OCR).
  for (let index = labelHit.lineIndex + 1; index < block.end && index < lines.length; index += 1) {
    const text = lines[index].items.map((item) => item.text).join(" ");
    const match = DOC_PATTERN.exec(text);
    if (!match) continue;
    const documento = validateDocumento(match[0]);
    if (documento) return documento;
  }
  return null;
}

interface Party {
  readonly nome: string | null;
  readonly documento: string | null;
  readonly blocoEncontrado: boolean;
}

const MISSING_PARTY: Party = {
  nome: null,
  documento: null,
  blocoEncontrado: false,
};

/** Extrai nome e documento estritamente dentro do bloco informado. */
function extractParty(lines: readonly Line[], sectionTitle: string): Party {
  const block = findBlock(lines, sectionTitle);
  if (!block) return MISSING_PARTY;

  const nomeHit = findLabel(lines, "NOME / NOME EMPRESARIAL", block.start + 1, block.end);
  const nomeRaw = nomeHit ? readColumnValue(lines, nomeHit) : null;

  return {
    blocoEncontrado: true,
    nome: nomeRaw ? validateNome(nomeRaw) : null,
    documento: findDocumentoInBlock(lines, block),
  };
}


/**
 * Extrai exclusivamente o conteúdo do campo DESCRIÇÃO DO SERVIÇO dentro
 * do bloco SERVIÇO PRESTADO. Não lê valores de impostos ou de outros blocos.
 */
function extractDescricaoServico(lines: readonly Line[]): string | null {
  const block = findBlock(lines, "SERVICO PRESTADO");
  if (!block) return null;

  // Alguns emissores gravam o rótulo inteiro em um único item do PDF;
  // outros o fragmentam em vários itens. A busca por linha cobre ambos.
  let labelLine = -1;
  for (let index = block.start + 1; index < block.end; index += 1) {
    const value = lines[index].normalized.replace(/[^A-Z0-9]+/g, " ").trim();
    if (/\bDESCRICAO\s+DO\s+SERVICO\b/.test(value)) {
      labelLine = index;
      break;
    }
  }
  if (labelLine < 0) return null;

  const parts: string[] = [];
  const labelX = lines[labelLine].items[0]?.x ?? 0;

  // Se o emissor colocou o conteúdo no mesmo item/linha do rótulo,
  // conserva apenas o trecho posterior a DESCRIÇÃO DO SERVIÇO.
  const labelText = lines[labelLine].items.map((item) => item.text).join(" ");
  const sameLine = labelText
    .replace(/^.*?DESCRI[CÇ][AÃ]O\s+DO\s+SERVI[CÇ]O\s*[:\-]?\s*/i, "")
    .replace(/\s+/g, " ")
    .trim();
  if (sameLine) parts.push(sameLine);

  // As linhas seguintes, até o fim do bloco SERVIÇO PRESTADO, pertencem
  // à descrição. Rótulos estruturais são ignorados por segurança.
  for (let index = labelLine + 1; index < block.end; index += 1) {
    const line = lines[index];
    const normalized = line.normalized;
    if (!normalized) continue;

    const structuralLabels = [
      "CODIGO DE TRIBUTACAO NACIONAL / MUNICIPAL",
      "CODIGO DA NBS",
      "LOCAL DA PRESTACAO / SIGLA UF / PAIS",
      "DESCRICAO DO CODIGO DE TRIBUTACAO NACIONAL / MUNICIPAL",
    ];
    if (structuralLabels.some((label) => similar(normalized, label))) continue;

    // A descrição fica alinhada à coluna do rótulo; fragmentos mais à direita
    // (ex.: carimbo "CANCELADA" fatiado pelo PDF) não fazem parte do texto.
    const column = line.items.filter((item) => item.x <= labelX + 60);
    const text = column
      .map((item) => item.text)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (text) parts.push(text);
  }

  const value = parts.join(" | ").replace(/\s+/g, " ").trim();
  return value || null;
}

/**
 * Padroniza somente as palavras-chave solicitadas, sem copiar valores,
 * nomes de passageiros ou outras partes da descrição para Detalhamento.
 *
 * Variações aceitas:
 * - DOM: DOM, DOMÉSTICO, DOMESTICO, DOMESTIC e pequenos erros de OCR;
 * - LAND: LAND, LANDSIDE, LAND SIDE e pequenos erros de OCR;
 * - Fast Pass: FAST PASS, FASTPASS, FAST-PASS, FAST TRACK;
 * - Meet & Assist: M&A, M & A, MEET ASSIST, MEET & ASSIST, MEET AND ASSIST.
 */
export function classifyServico(descricao: string | null): string {
  if (!descricao) return NOT_FOUND;
  const value = normalize(descricao);
  const compact = value.replace(/[^A-Z0-9]/g, "");
  const words = value.replace(/[^A-Z0-9]+/g, " ").trim().split(" ").filter(Boolean);
  const nearWord = (targets: readonly string[], maxDistance = 1) =>
    words.some((word) =>
      word.length >= 3 &&
      // Alvos curtos (LAND) exigem igualdade exata: "AND" estaria a 1 letra de "LAND".
      targets.some(
        (target) => levenshtein(word, target) <= (target.length <= 4 ? 0 : maxDistance),
      ),
    );

  const matches: string[] = [];

  // DOM deve ser palavra isolada para não confundir com outros termos.
  if (
    /(^|[^A-Z0-9])D[O0]M([^A-Z0-9]|$)/.test(value) ||
    nearWord(["DOMESTICO", "DOMESTICA", "DOMESTIC"])
  ) matches.push("DOM");

  if (
    /(^|[^A-Z0-9])LAND(?:\s*[- ]?\s*SIDE)?([^A-Z0-9]|$)/.test(value) ||
    nearWord(["LANDSIDE", "LANSIDE", "LAND"])
  ) matches.push("LAND");

  if (
    /(^|[^A-Z0-9])FAST\s*[- ]?\s*(?:PASS|PASSE|TRACK)([^A-Z0-9]|$)/.test(value) ||
    /FASTPASS|FASTPASSE|FASTTRACK/.test(compact)
  ) matches.push("Fast Pass");

  if (
    /(^|[^A-Z0-9])M\s*(?:&|E|AND)\s*A([^A-Z0-9]|$)/.test(value) ||
    // "MA" / "M.A." / "M A" isolados (não casa MASTERCARD, MAIS etc.)
    /(^|[^A-Z0-9])M\.\s*A\.?([^A-Z0-9]|$)|(^|[^A-Z0-9])MA([^A-Z0-9]|$)/.test(value) ||
    /(^|[^A-Z0-9])MEET\s*(?:&|E|AND)?\s*ASSIST\w*/.test(value) ||
    /(^|[^A-Z0-9])MEET\s*(?:&|E|AND)?\s*(?:GREET|ASSIT|ASIST)/.test(value) ||
    /MEETASSIST|MEETANDASSIST|MEET&ASSIST/.test(compact)
  ) matches.push("Meet & Assist");

  return matches.length > 0 ? matches.join(" + ") : "OUTRO";
}

/** Escolhe o primeiro bloco que realmente exista, na ordem informada. */
function firstParty(lines: readonly Line[], titles: readonly string[]): Party {
  let best = MISSING_PARTY;
  for (const title of titles) {
    const party = extractParty(lines, title);
    if (!party.blocoEncontrado) continue;
    if (party.nome && party.documento) return party;
    if (!best.blocoEncontrado || (!best.documento && party.documento)) {
      best = party;
    }
  }
  return best;
}

export interface ParseResult {
  readonly record: Omit<NfseRecord, "arquivo" | "origem" | "cancelada">;
  readonly confident: boolean;
}

/**
 * Camada 4: extração orientada aos blocos oficiais do DANFSe v2.0.
 * Nenhum campo é preenchido por adivinhação — falhou, vira NÃO IDENTIFICADO
 * acompanhado do motivo em `camposFaltantes`.
 */
export function parseDanfse(layout: DocumentLayout): ParseResult {
  const { lines } = layout;

  const numeroHit = findLabel(lines, "NUMERO DA NFS-E");
  const competenciaHit = findLabel(lines, "COMPETENCIA DA NFS-E");
  const emissaoHit = findLabel(lines, "DATA E HORA DA EMISSAO DA NFS-E");

  const numero = numeroHit ? validateNumero(readColumnValue(lines, numeroHit) ?? "") : null;
  const competencia = competenciaHit
    ? validateCompetencia(readColumnValue(lines, competenciaHit) ?? "")
    : null;
  const dataEmissao = emissaoHit
    ? validateDataEmissao(readColumnValue(lines, emissaoHit) ?? "")
    : null;

  const emitente = firstParty(lines, ["PRESTADOR / FORNECEDOR", "EMITENTE DA NFS-E"]);
  const tomador = firstParty(lines, ["TOMADOR / ADQUIRENTE", "DESTINATARIO DA OPERACAO"]);
  const descricaoServico = extractDescricaoServico(lines);
  const tipoServico = classifyServico(descricaoServico);

  // Valor: exclusivamente "VALOR DA OPERAÇÃO / SERVIÇO" dentro do bloco
  // "VALOR TOTAL DA NFS-E" — nunca líquido, retenções, IBS/CBS ou descontos.
  let valorTotal: string | null = null;
  const valorBlock = findBlock(lines, "VALOR TOTAL DA NFS-E");
  if (valorBlock) {
    // Layout atual: rótulo na linha acima do título e valor na linha do título.
    const valorHit = findLabel(
      lines,
      "VALOR DA OPERACAO / SERVICO",
      Math.max(0, valorBlock.start - 2),
      valorBlock.end,
    );
    if (valorHit) valorTotal = validateValor(readColumnValue(lines, valorHit) ?? "");
  }

  const camposFaltantes: string[] = [];
  const finalize = (value: string | null, label: string, motivo: string): string => {
    if (value) return value;
    camposFaltantes.push(`${label}: ${motivo}`);
    return NOT_FOUND;
  };

  const partyReason = (party: Party, bloco: string, campo: string) =>
    party.blocoEncontrado
      ? `${campo} não localizado dentro do bloco ${bloco}`
      : `Bloco ${bloco} não localizado`;

  const record = {
    numero: finalize(numero, "Número NFS-e", "Rótulo NÚMERO DA NFS-E ausente ou valor inválido"),
    competencia: finalize(
      competencia,
      "Competência",
      "Rótulo COMPETÊNCIA DA NFS-E ausente ou valor inválido",
    ),
    dataEmissao: finalize(
      dataEmissao,
      "Data Emissão",
      "Rótulo DATA E HORA DA EMISSÃO ausente ou valor inválido",
    ),
    emitente: finalize(
      emitente.nome,
      "Emitente",
      partyReason(emitente, "EMITENTE DA NFS-E", "NOME / NOME EMPRESARIAL"),
    ),
    cnpjEmitente: finalize(
      emitente.documento,
      "CNPJ Emitente",
      partyReason(emitente, "EMITENTE DA NFS-E", "CNPJ / CPF / NIF"),
    ),
    tomador: finalize(
      tomador.nome,
      "Tomador",
      partyReason(tomador, "TOMADOR / ADQUIRENTE", "NOME / NOME EMPRESARIAL"),
    ),
    cnpjTomador: finalize(
      tomador.documento,
      "CNPJ Tomador",
      partyReason(tomador, "TOMADOR / ADQUIRENTE", "CNPJ / CPF / NIF"),
    ),
    descricaoServico: finalize(
      descricaoServico,
      "Descrição do Serviço",
      "Rótulo DESCRIÇÃO DO SERVIÇO ausente ou conteúdo não localizado dentro de SERVIÇO PRESTADO",
    ),
    tipoServico,
    valorTotal: finalize(
      valorTotal,
      "Valor Total",
      valorBlock
        ? "VALOR DA OPERAÇÃO / SERVIÇO não localizado no bloco VALOR TOTAL DA NFS-E"
        : "Bloco VALOR TOTAL DA NFS-E não localizado",
    ),
    camposFaltantes,
  } satisfies Omit<NfseRecord, "arquivo" | "origem" | "cancelada">;

  return { record, confident: camposFaltantes.length === 0 };
}
