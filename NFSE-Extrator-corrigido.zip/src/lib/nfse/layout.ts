import type { Line, PositionedItem } from "./types";

/** Normaliza texto: sem acentos, maiúsculas, espaços colapsados. */
export function normalize(input: string): string {
  return input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Agrupa itens posicionados em linhas, tolerando pequenas variações de Y
 * (PDFs com leve rotação ou OCR ruidoso).
 */
export function buildLines(items: readonly PositionedItem[], tolerance = 3): Line[] {
  const clean = items.filter((item) => item.text.trim().length > 0);
  if (clean.length === 0) return [];

  const sorted = [...clean].sort((a, b) => a.y - b.y || a.x - b.x);
  const buckets: PositionedItem[][] = [];
  let current: PositionedItem[] = [sorted[0]];
  let anchorY = sorted[0].y;

  for (const item of sorted.slice(1)) {
    if (Math.abs(item.y - anchorY) <= tolerance) {
      current.push(item);
    } else {
      buckets.push(current);
      current = [item];
      anchorY = item.y;
    }
  }
  buckets.push(current);

  return buckets.map((bucket) => {
    const items = [...bucket].sort((a, b) => a.x - b.x);
    return {
      y: items[0].y,
      items,
      normalized: normalize(items.map((i) => i.text).join(" ")),
    } satisfies Line;
  });
}

/** Texto completo do documento, uma linha por linha reconstruída. */
export function linesToText(lines: readonly Line[]): string {
  return lines.map((line) => line.items.map((i) => i.text).join(" ")).join("\n");
}
