# Gerar o instalador sem acesso de administrador

Você não precisa instalar Visual Studio, Rust, Node.js ou VS Code. A geração ocorre em um computador do GitHub e você baixa o instalador pronto pelo navegador.

## Primeira vez

1. Entre em https://github.com e crie uma conta gratuita, se ainda não tiver.
2. Clique em **New repository**.
3. Escolha um nome, por exemplo `nfse-extrator`, marque **Private** e crie o repositório.
4. Na página vazia do repositório, clique em **uploading an existing file**.
5. Extraia este ZIP no seu computador e arraste para a página do GitHub todo o conteúdo da pasta `NFSE-Extrator`, inclusive as pastas `.github`, `src` e `src-tauri`.
6. Clique em **Commit changes** e aguarde o envio terminar.

## Gerar o EXE

1. Abra a aba **Actions** do repositório.
2. No lado esquerdo, clique em **Gerar instalador Windows**.
3. Clique em **Run workflow** e depois no botão verde **Run workflow**.
4. Aguarde a execução ficar verde.
5. Abra a execução concluída e, no fim da página, baixe **Extrator-NFSe-Instalador-Windows**.
6. Extraia o ZIP baixado. Dentro estará o instalador `.exe`.

O instalador é configurado apenas para o usuário atual do Windows e não exige conta de administrador.

## Quando alterar o código

Envie os arquivos alterados ao mesmo repositório e repita apenas os passos de **Gerar o EXE**. O computador do usuário final recebe somente o instalador; ele não precisa de GitHub, VS Code, Node.js ou Rust.

## Observação sobre o antivírus

Um `.exe` novo e sem assinatura digital pode receber alerta de reputação, mesmo quando não contém vírus. Evite renomear ou compactar repetidamente o instalador. Para distribuição ampla em empresas, a forma profissional de reduzir esses alertas é assinar o instalador com um certificado de assinatura de código.
