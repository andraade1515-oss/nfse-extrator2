fn main() {
    nfse_extrator_lib::run();
}
