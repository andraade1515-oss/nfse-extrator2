# Atualização 2.1 - Detalhamento do serviço

## Alterações

- leitura reforçada do bloco `DESCRIÇÃO DO SERVIÇO`;
- texto completo preservado na coluna `Descrição do Serviço`;
- nova coluna de saída `Detalhamento` somente com palavras-chave padronizadas;
- reconhecimento de `DOM`, `LAND`, `Fast Pass` e `Meet & Assist`;
- tolerância a acentos, maiúsculas, espaços, hífens e pequenos erros de OCR.

## Atualizar o arquivo no GitHub

1. Abra o repositório `nfse-extrator`.
2. Clique no arquivo `NFSE-Extrator-GitHub-Sem-Admin.zip`.
3. Abra o menu de três pontos e escolha `Delete file`.
4. Confirme em `Commit changes`.
5. Volte à página principal e use `Add file` > `Upload files`.
6. Envie o novo arquivo com o mesmo nome.
7. Confirme em `Commit changes`.
8. Abra `Actions` > `Gerar instalador Windows` > `Run workflow`.

Não altere o arquivo da automação: o nome e a estrutura do ZIP continuam iguais.
